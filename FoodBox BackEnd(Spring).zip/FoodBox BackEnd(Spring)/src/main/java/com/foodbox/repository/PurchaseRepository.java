package com.foodbox.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.foodbox.model.Purchase;

public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
	@Query("Select p FROM Purchase p WHERE p.customer.email LIKE %?1%")
	public List<Purchase> getByEmail(String email);
	
	
	//This method retrieves all Purchase entities and orders them by transaction ID in ascending order:Bharath reddy 
	public List<Purchase> findAllByOrderByTransactionidAsc();
	
	
	//searching purchase function implemented here :Bharath Reddy 
	@Query("Select p FROM Purchase p WHERE p.transactionid LIKE %?1%"
		
			+" OR p.productname LIKE %?1%"
			+" OR p.customer LIKE %?1%")
	
	//custom query method that allows you to search for purchases in the database based on a provided keyword:Bharath Reddy 
	public List<Purchase> searchPurchase(String keyword);
}
